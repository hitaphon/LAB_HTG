from cryptography.fernet import Fernet

def generate_key():
    key = Fernet.generate_key()
    with open("key.txt", "wb") as key_file:
        key_file.write(key)

def load_key():
    return open("key.txt", "rb").read()

def encrypt_file(filename, key):
    fernet = Fernet(key)
    with open(filename, "rb") as file:
        file_data = file.read()
    encrypted_data = fernet.encrypt(file_data)
    with open(filename + ".encrypted", "wb") as file:
        file.write(encrypted_data)

def decrypt_file(filename, key):
    fernet = Fernet(key)
    with open(filename, "rb") as file:
        encrypted_data = file.read()
    decrypted_data = fernet.decrypt(encrypted_data)
    with open(filename[:-10], "wb") as file:
        file.write(decrypted_data)

def encrypt_file_with_key(filename):
    generate_key()
    key = load_key()
    encrypt_file(filename, key)
encrypt_file_with_key("hostbase.txt")
