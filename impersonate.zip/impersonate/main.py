from scapy.all import Ether, ARP, sendp

# Define the old and new MAC addresses
old_mac = "08:00:27:b7:6c:b4"  # Replace with the old MAC address
new_mac = "AA:BB:CC:DD:EE:FF"  # Replace with the new MAC address

# Define the source IP address
source_ip = "192.168.56.3"  # Replace with the source IP address you want to use

# Create an ARP announcement packet with custom source IP
arp_announcement = Ether(dst="ff:ff:ff:ff:ff:ff", src=new_mac)/ARP(op="is-at", psrc=source_ip, hwsrc=new_mac)

# Display the ARP announcement packet
arp_announcement.show()

# Send the ARP announcement packet
sendp(arp_announcement, iface="enp0s8")  # Replace "eth0" with your network interface
