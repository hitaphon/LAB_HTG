<html>
  <link rel="stylesheet" id="base" href="/css/default.css" type="text/css" media="screen" />


  <title>Administration of my Awesome Photoblog</title>
  <body>
  <div id="header">
    <div id="logo">
      <h1><a href="index.php">Administration of my Awesome Photoblog</a></h1>
    </div>
    <div id="menu">
      <ul>
        <li class="active">
            <a href="/"> Home  |</a>
        </li>
        <li>
          <a href="/admin/">Manage pictures |</a>
        </li> 
 
        <li>
          <a href="/admin/new.php">New picture |</a>
        </li>
        <li>
          <a href="/admin/logout.php">Logout</a>
        </li>
 
        </ul>
      </div>
    </div>

  
