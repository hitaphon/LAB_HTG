<?php
if (!extension_loaded('gd')) {
  DIE("NEED gd library to work");
}

class Picture{

  public $id, $title, $img, $cat;

  function __construct($id = null, $title = null, $img = null, $cat = null){
    if($id !== null && $title !== null && $img !== null && $cat !== null){
      $this->title= $title;
      $this->img = $img;
      $this->id = $id;
      $this->cat = $cat;
    }
  }   
  static function all($conn, $cat = NULL, $order = NULL) {
    if (!isset($cat)) {
        $results = mysqli_query($conn, "SELECT * FROM pictures");
    } else {
        $cat = intval($cat);
        $results = mysqli_query($conn, "SELECT * FROM pictures WHERE cat=" . $cat);
    }

    $pictures = array();
    if ($results) {
        while ($row = mysqli_fetch_assoc($results)) {
            $pictures[] = new Picture($row['id'], $row['title'], $row['img'], $row['cat']);
        }
    } else {
        echo mysqli_error($conn);
    }

    return $pictures;
}
  function render_all($pics) {
    echo "<ul>\n";
    foreach ($pics as $pic) {
        echo "\t<li>" . $pic->render() . "</li>\n";
    }
    echo "</ul>\n";
}

function render_edit() {
    $str = "<img src=\"uploads/" . h($this->img) . "\" alt=\"" . h($this->title) . "\" />";
    return $str;
}

function render() {
    $str = "<img src=\"admin/uploads/" . h($this->img) . "\" alt=\"" . h($this->title) . "\" />";
    return $str;
}

static function find($conn,$id) {
  if (!preg_match('/^[0-9]+$/', $id)) {
      die("ERROR: INTEGER REQUIRED");
  }
  // SQL injection risk: $id is directly concatenated into the query
  $result = mysqli_query($conn, "SELECT * FROM pictures where id=" . $id);
  $row = mysqli_fetch_assoc($result);
  if (isset($row)) {
      $picture = new Picture($row['id'], $row['title'], $row['img'], $row['cat']);
  }
  return $picture;
}

static function delete($conn,$id) {
  if (!preg_match('/^[0-9]+$/', $id)) {
      die("ERROR: INTEGER REQUIRED");
  }
  $result = mysqli_query($conn,"DELETE FROM pictures where id=" . (int)$id);
  // should unlink the file
}

static function last($conn) {
  $result = mysqli_query($conn,"SELECT * FROM pictures ORDER BY id DESC LIMIT 1");
  $row = mysqli_fetch_assoc($result);
  if (isset($row)) {
      return new Picture($row['id'], $row['title'], $row['img'], $row['cat']);
  }
}

static function show($conn,$id) {
  $result = mysqli_query($conn,"SELECT * FROM pictures where id=" . intval($id));
  $row = mysqli_fetch_assoc($result);
  if (isset($row)) {
      return new Picture($row['id'], $row['title'], $row['img'], $row['cat']);
  }
}
  
static function create($conn) {
  if (!isset($_FILES['image'])) {
      die("No image file uploaded");
  }

  $uploadDirectory = '/var/www/sqlweb/admin/uploads/';
  $file = basename($_FILES['image']['name']);
  $ext = pathinfo($file, PATHINFO_EXTENSION);
  $base = $_FILES['image']['tmp_name'];

  if (!$base) {
      die("Invalid file");
  }

  $newFilename = time() . "." . $ext;
  $destination = $uploadDirectory . $newFilename;

  if (!move_uploaded_file($base, $destination)) {
      die("Error during upload: Unable to move file");
  }

  $title = mysqli_real_escape_string($conn, $_POST["title"] ?? "");
  $img = mysqli_real_escape_string($conn, $newFilename);
  $cat = isset($_POST["category"]) ? (int)$_POST["category"] : 0;

  $sql = "INSERT INTO pictures (title, img, cat) VALUES ('$title', '$img', '$cat')";
  $result = mysqli_query($conn, $sql);

  if (!$result) {
      die("Error in SQL query: " . mysqli_error($conn));
  }
}


}
?>