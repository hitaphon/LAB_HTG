<?php

	ini_set ('display_errors', 1);
	ini_set ('display_startup_errors', 1);
	error_reporting (E_ALL);

	$servername = "localhost";
	$username = "pentesterlab";
	$password = "pentesterlab";
	$database = "photoblog";

	$conn = new mysqli($servername, $username, $password, $database);

	if($conn -> connect_error){
		die("Connection failed: ".$conn -> connect_error);
	}

	echo "<script>console.log('Connected to database successfully');</script>";

?>