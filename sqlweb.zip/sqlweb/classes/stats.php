<?php

  $ip = $_SERVER['REMOTE_ADDR'];

  if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip= $_SERVER['HTTP_X_FORWARDED_FOR'];
  }
  $results = mysqli_query($conn,"SELECT * FROM stats where ip='".$ip."'");
  if ($results) {
      $row = mysqli_fetch_assoc($results);
      if ($row && isset($row['ip'])) {
        // Update the existing record
        mysqli_query($conn, "UPDATE stats SET count = count + 1 WHERE ip = '".$ip."'");
    } else {
        // Insert a new record
        mysqli_query($conn, "INSERT INTO stats (ip, count) VALUES ('".$ip."', 1)");
    }
  }
?>
