<?php

class Category {
    const SITE = "PHOTOBLOG";

    public $title, $id;

    function __construct($id = null, $title = null) {
        if ($id !== null && $title !== null) {
            $this->id = $id;
            $this->title = $title;
        }
    }

    static function all($conn) {
        $sql = "SELECT * FROM categories";
        $results = mysqli_query($conn, $sql);
        $categories = array();
        if($results){
          while ($row = mysqli_fetch_assoc($results)) {
            $categories[] = new Category($row['id'], $row['title']);
          }
        } else{
          echo mysqli_error($conn);
        }
        
        return $categories;
    }

    function render_menu($conn) {
        foreach (self::all($conn) as $cat) {
            echo "\t<li><a href=\"cat.php?id=" . h($cat->id) . "\">" . h($cat->title) . " | </a></li>\n";
        }
    }
    static function render_select($conn) {
      echo "<li><select name=\"category\" id=\"category\" onchange=\"redirectToSelectedCategory()\" style='margin-left:10px;margin-top:5px;'>";
      foreach (self::all($conn) as $cat) {
          $selected = isset($_GET['id']) && $_GET['id'] == $cat->id ? 'selected' : '';
          echo "<option value=" . h($cat->id) . " $selected>" . h($cat->title) . "</option>";
      }
      echo "</select></li>";
  
      // JavaScript function to handle onchange event and redirect
      echo "<script>
              function redirectToSelectedCategory() {
                  var selectedValue = document.getElementById('category').value;
                  // Redirect to cat.php?id=selected_value
                  window.location.href = 'cat.php?id=' + selectedValue;
              }
            </script>";
  }
}
?>
