<?php

class User {
  const SITE= "PHOTOBLOG";
  static function login($conn,$user, $password) {
    $sql = "SELECT * FROM users where login=\"";
    $sql.= mysqli_real_escape_string($conn,$user);
    $sql.= "\" and password=md5(\"";
    $sql.= mysqli_real_escape_string($conn,$password);
    $sql.= "\")";
    $result = mysqli_query($conn,$sql);
    if ($result) {
      $row = mysqli_fetch_assoc($result);
      if ($user === $row['login']) {
        return TRUE;
      }
    }
    else 
      echo mysql_error();
    return FALSE;
    //die("invalid username/password");
  }


}
?>
