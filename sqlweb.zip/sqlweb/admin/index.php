<?php 
  require("../classes/auth.php");
  require("header.php");
  require("../classes/db.php");
  require("../classes/phpfix.php");
  require("../classes/picture.php");

   if(isset($_FILES['image'])){
      Picture::create($conn);
   }
?>

<div style="display:flex;align-items:center;flex-direction:column;margin-top:50px;">
<table border=1>
<tr>
  <th style='padding:5px;'>Picture Name</th>
  <th></th>
</tr>

<?php  
  $pictures= Picture::all($conn);

  foreach ($pictures as $picture) {
    echo "<tr>";
    echo "<td style='padding:5px; width:200px;'><a href=\"../show.php?id=".h($picture->id)."\">".h($picture->title)."</a></td>";
    echo "<td style='padding:5px; width:50px;'><a href=\"del.php?id=".h($picture->id)."\">delete</a></td>";
    echo "</tr>";
  }
?>
</table>
<a style="margin:10px;" href="new.php"> Add a new picture</a>
</div>
<?php
  require("footer.php");

?>

