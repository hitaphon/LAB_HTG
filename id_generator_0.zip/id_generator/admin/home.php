<h1>Welcome to <?php echo $_settings->info('name') ?></h1>
<hr class="bg-light">

